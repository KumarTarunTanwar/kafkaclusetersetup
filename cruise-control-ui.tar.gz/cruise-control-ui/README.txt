
Version-0.1.0
=============
Place the contents of dist/* under a webserver or cruise control to start serving

Its important to update the static/config.csv to include right URLs for the CC instances
